# Stock Consultant Agent 📈

A comprehensive AI-powered portfolio analysis platform that provides actionable investment advice in plain English. Built for beginners and small investors who want smart, data-driven recommendations without the complexity of traditional financial platforms.

![StockConsultant Banner](https://via.placeholder.com/800x400/2563eb/ffffff?text=StockConsultant+Agent)

## 🌟 Key Features

### ✅ Currently Implemented Features

1. **Modern Portfolio Input Interface**
   - Dynamic stock entry with real-time validation
   - Auto-suggestions for stock symbols
   - Support for Indian stock market (NSE/BSE)
   - Portfolio naming and management

2. **Interactive Analysis Progress Tracking**
   - Real-time progress visualization with 4-step process
   - Live progress bar and step-by-step status updates
   - Animated progress sidebar during analysis

3. **AI-Powered Stock Analysis Engine**
   - Buy/Sell/Hold/Diversify recommendations
   - Risk assessment (Low/Medium/High)
   - Plain English explanations for each recommendation
   - Portfolio scoring system (1-10 scale)

4. **Comprehensive Visualization Dashboard**
   - Portfolio allocation pie charts
   - Sector diversification analysis
   - Risk distribution visualization
   - Performance metrics and P&L tracking

5. **Usage Tracking & Billing System**
   - Flexprice integration for per-analysis billing
   - Credit-based system with transparent pricing
   - Usage history and statistics
   - Export functionality for billing data

6. **Live Mock Stock Data Integration**
   - Pathway-simulated real-time stock prices
   - 10+ major Indian stocks with live data
   - Market metrics (PE ratio, market cap, day change)
   - Automatic data refresh capabilities

## 🎯 Functional Entry Points

### Main Application URLs

- **Homepage**: `/` - Landing page with hero section and features
- **Portfolio Builder**: `/#portfolio` - Create and manage portfolios  
- **Analysis Dashboard**: `/#analysis` - View analysis results and charts
- **Usage Tracking**: `/#usage` - Monitor credits and billing history

### API Endpoints (RESTful Table API)

**Portfolio Management:**
- `GET /tables/portfolios` - List user portfolios
- `POST /tables/portfolios` - Create new portfolio
- `GET /tables/portfolios/{id}` - Get specific portfolio
- `PUT /tables/portfolios/{id}` - Update portfolio
- `DELETE /tables/portfolios/{id}` - Delete portfolio

**Stock Data:**
- `GET /tables/stock_data` - Get stock market data
- `GET /tables/stock_data?search={symbol}` - Search stocks by symbol
- `POST /tables/stock_data` - Add new stock data

**Analysis Results:**
- `GET /tables/stock_analyses` - Get analysis results
- `POST /tables/stock_analyses` - Save analysis results
- `GET /tables/stock_analyses?portfolio_id={id}` - Get portfolio analysis

**Usage Tracking:**
- `GET /tables/usage_tracking` - Get usage history
- `POST /tables/usage_tracking` - Record new usage
- `GET /tables/usage_tracking?search={user}` - Get user-specific usage

## 🚀 Quick Start Guide

### For Users:

1. **Create Your Portfolio**
   - Enter your name and portfolio name
   - Add stocks with symbols, quantities, and average prices
   - Use auto-suggestions for accurate stock symbols

2. **Analyze Your Portfolio**
   - Click "Analyze Portfolio" (costs ₹10/10 credits)
   - Watch the real-time progress tracking
   - View comprehensive results in 30-60 seconds

3. **Review Recommendations**
   - Get plain English advice for each stock
   - Understand risk levels and diversification needs
   - Generate detailed reports (costs ₹5 additional)

4. **Track Your Usage**
   - Monitor your credit consumption
   - Export usage data for records
   - View analysis history and performance

### For Developers:

1. **File Structure Overview**
```
├── index.html              # Main application page
├── css/
│   └── main.css            # Complete styling system
├── js/
│   ├── main.js             # Core utilities and initialization
│   ├── portfolio.js        # Portfolio management and analysis
│   ├── analysis.js         # Results visualization and charts
│   └── usage.js            # Billing and usage tracking
└── README.md               # This documentation
```

2. **Key Functions**
```javascript
// Portfolio Analysis
analyzePortfolio()          // Main analysis function
showAnalysisResults()       // Display results dashboard

// Data Management  
collectPortfolioData()      // Extract form data
fetchLiveStockData()        // Get current prices
performAIAnalysis()         // Generate recommendations

// Usage & Billing
deductCredits()             // Process payments
recordUsage()               # Track billing events
loadUsageStats()            // Display usage dashboard
```

## 💰 Pricing & Billing (Flexprice Integration)

- **Portfolio Analysis**: ₹10 per analysis
- **Detailed Report**: ₹5 per report  
- **Stock Advice**: ₹2 per individual stock query
- **Credit System**: 1 credit = ₹1

**Usage Tracking:**
- Real-time credit balance
- Detailed usage history
- Export billing data
- Transparent cost breakdown

## 📊 Data Models & Storage

### Database Tables

1. **portfolios**
   - `id` (text): Unique portfolio identifier
   - `user_name` (text): Portfolio owner name
   - `portfolio_name` (text): User-defined portfolio name
   - `stocks` (array): Stock holdings with quantities/prices
   - `total_investment` (number): Total invested amount
   - `created_date` (datetime): Creation timestamp
   - `last_analyzed` (datetime): Last analysis date

2. **stock_data**
   - `symbol` (text): Stock ticker symbol
   - `company_name` (text): Full company name
   - `current_price` (number): Live stock price
   - `day_change` (number): Daily percentage change
   - `pe_ratio` (number): Price-to-earnings ratio
   - `sector` (text): Industry sector
   - `market_cap` (number): Market capitalization

3. **stock_analyses**
   - `portfolio_id` (text): Reference to analyzed portfolio
   - `stock_symbol` (text): Analyzed stock
   - `recommendation` (text): BUY/SELL/HOLD/DIVERSIFY
   - `reason` (text): Plain English explanation
   - `risk_level` (text): LOW/MEDIUM/HIGH
   - `current_price` (number): Analysis-time price
   - `target_price` (number): Recommended target

4. **usage_tracking**
   - `user_name` (text): User identifier
   - `action_type` (text): PORTFOLIO_ANALYSIS/REPORT_GENERATED/STOCK_ADVICE
   - `cost` (number): Credit cost
   - `timestamp` (datetime): Action timestamp
   - `details` (text): Additional context

## 🔮 Features Not Yet Implemented

### High Priority (Next Phase)
- [ ] **Real Stock Market API Integration**
  - Live data from NSE/BSE APIs
  - Real-time price updates
  - Extended stock universe (1000+ stocks)

- [ ] **Advanced AI Recommendations**
  - Machine learning-based predictions
  - Historical performance analysis
  - Risk-adjusted return calculations

- [ ] **User Authentication System**
  - Secure login/registration
  - Password recovery
  - Profile management

### Medium Priority
- [ ] **Portfolio Comparison Tools**
  - Benchmark against market indices
  - Peer portfolio comparisons
  - Performance attribution analysis

- [ ] **Advanced Charting**
  - Interactive price charts
  - Technical indicators
  - Trend analysis

- [ ] **Notification System**
  - Price alerts
  - Recommendation updates
  - Portfolio rebalancing reminders

### Low Priority (Future Enhancements)
- [ ] **Mobile Application**
  - Native iOS/Android apps
  - Push notifications
  - Offline analysis capability

- [ ] **Social Features**
  - Portfolio sharing
  - Community discussions
  - Expert advisor connections

- [ ] **Advanced Reports**
  - PDF generation
  - Automated email reports
  - Tax optimization suggestions

## 🔧 Technical Architecture

### Frontend Stack
- **HTML5**: Semantic markup with accessibility features
- **CSS3**: Modern styling with CSS Grid, Flexbox, animations
- **JavaScript ES6+**: Modular architecture with async/await
- **Chart.js**: Interactive data visualizations
- **Font Awesome**: Icon library
- **Google Fonts**: Typography (Inter font family)

### Data Layer
- **RESTful Table API**: Full CRUD operations
- **JSON Storage**: Structured data persistence
- **Real-time Updates**: Live data synchronization

### Integration Points
- **Flexprice API**: Billing and payment processing
- **Pathway Data**: Mock stock market simulation
- **Export Functions**: CSV/PDF report generation

## 🚀 Recommended Next Steps

### Phase 1: Core Enhancements (2-3 weeks)
1. **Integrate Real Market Data APIs**
   - Connect to NSE/BSE live feeds
   - Implement data caching layer
   - Add error handling for API failures

2. **Enhanced User Management**  
   - Add user registration/login
   - Implement session management
   - Create user preference settings

### Phase 2: Advanced Features (4-6 weeks)
1. **Machine Learning Integration**
   - Implement predictive analytics
   - Add sentiment analysis from news
   - Create risk scoring algorithms

2. **Mobile Optimization**
   - Responsive design improvements
   - Progressive Web App (PWA) features
   - Touch-optimized interactions

### Phase 3: Scale & Polish (6-8 weeks)
1. **Performance Optimization**
   - Implement caching strategies
   - Optimize bundle sizes
   - Add service worker for offline support

2. **Advanced Analytics**
   - Portfolio performance tracking over time
   - Benchmark comparisons
   - Tax-loss harvesting suggestions

## 🔐 Security & Compliance

### Data Protection
- All user data is stored securely
- No sensitive financial account information is collected
- GDPR-compliant data handling practices

### Investment Disclaimer
⚠️ **Important**: This platform provides educational analysis only and should not be considered as professional investment advice. Users should consult qualified financial advisors before making investment decisions.

### Risk Warnings
- Stock investments carry inherent risks
- Past performance does not guarantee future results
- Diversification does not eliminate investment risk

## 🤝 Contributing

We welcome contributions! Please see our contributing guidelines for:
- Code style requirements
- Pull request process
- Issue reporting templates
- Feature request procedures

## 📞 Support & Contact

- **Email**: support@stockconsultant.com
- **Documentation**: Available in-app help system
- **Bug Reports**: Use GitHub issues
- **Feature Requests**: Community voting system

---

**Built with ❤️ for Indian retail investors** | **Not SEBI registered - For educational purposes only**

*Last Updated: December 19, 2024*