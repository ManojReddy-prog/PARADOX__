// Portfolio Management JavaScript
// Handles portfolio creation, editing, and management

let stockRowCounter = 0;

/**
 * Add a new stock row to the portfolio form
 */
function addStockRow() {
    stockRowCounter++;
    const container = document.getElementById('stocks-container');
    
    const stockRow = document.createElement('div');
    stockRow.className = 'stock-row';
    stockRow.setAttribute('data-row', stockRowCounter);
    
    stockRow.innerHTML = `
        <div class="stock-input-group">
            <input type="text" placeholder="Stock Symbol (e.g., TCS)" class="stock-symbol" list="stock-suggestions">
            <input type="number" placeholder="Quantity" class="stock-quantity" min="1">
            <input type="number" placeholder="Avg Price ₹" class="stock-price" min="0" step="0.01">
            <button type="button" class="btn-remove-stock" onclick="removeStockRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    container.appendChild(stockRow);
    
    // Setup validation for new inputs
    const newInputs = stockRow.querySelectorAll('input');
    newInputs.forEach(input => {
        input.addEventListener('blur', validateInput);
        input.addEventListener('input', clearValidationError);
        
        if (input.classList.contains('stock-symbol')) {
            input.addEventListener('input', async function() {
                const query = this.value.toUpperCase();
                if (query.length >= 2) {
                    await updateStockSuggestions(query);
                }
            });
        }
    });
    
    // Focus on the new stock symbol input
    stockRow.querySelector('.stock-symbol').focus();
    
    showNotification('New stock row added', 'success', 2000);
}

/**
 * Remove a stock row from the portfolio form
 */
function removeStockRow(button) {
    const stockRow = button.closest('.stock-row');
    const container = document.getElementById('stocks-container');
    
    // Don't remove if it's the last row
    if (container.children.length <= 1) {
        showNotification('At least one stock is required', 'warning', 3000);
        return;
    }
    
    // Animate out
    stockRow.style.animation = 'slideOutRight 0.3s ease-out forwards';
    setTimeout(() => {
        if (stockRow.parentNode) {
            stockRow.parentNode.removeChild(stockRow);
        }
    }, 300);
    
    showNotification('Stock removed', 'info', 2000);
}

/**
 * Validate portfolio form
 */
function validatePortfolioForm() {
    let isValid = true;
    const errors = [];
    
    // Check portfolio name
    const portfolioName = document.getElementById('portfolio-name').value.trim();
    if (!portfolioName) {
        errors.push('Portfolio name is required');
        document.getElementById('portfolio-name').classList.add('error');
        isValid = false;
    }
    
    // Check investor name
    const investorName = document.getElementById('investor-name').value.trim();
    if (!investorName) {
        errors.push('Investor name is required');
        document.getElementById('investor-name').classList.add('error');
        isValid = false;
    }
    
    // Check stocks
    const stockRows = document.querySelectorAll('.stock-row');
    let validStocks = 0;
    
    stockRows.forEach((row, index) => {
        const symbol = row.querySelector('.stock-symbol').value.trim().toUpperCase();
        const quantity = row.querySelector('.stock-quantity').value;
        const price = row.querySelector('.stock-price').value;
        
        if (symbol || quantity || price) {
            // If any field is filled, all fields are required
            if (!symbol || !isValidStockSymbol(symbol)) {
                errors.push(`Invalid stock symbol in row ${index + 1}`);
                row.querySelector('.stock-symbol').classList.add('error');
                isValid = false;
            }
            
            if (!quantity || !Number.isInteger(Number(quantity)) || Number(quantity) <= 0) {
                errors.push(`Invalid quantity in row ${index + 1}`);
                row.querySelector('.stock-quantity').classList.add('error');
                isValid = false;
            }
            
            if (!price || isNaN(Number(price)) || Number(price) <= 0) {
                errors.push(`Invalid price in row ${index + 1}`);
                row.querySelector('.stock-price').classList.add('error');
                isValid = false;
            }
            
            if (symbol && quantity && price && 
                isValidStockSymbol(symbol) && 
                Number.isInteger(Number(quantity)) && Number(quantity) > 0 &&
                !isNaN(Number(price)) && Number(price) > 0) {
                validStocks++;
            }
        }
    });
    
    if (validStocks === 0) {
        errors.push('At least one valid stock is required');
        isValid = false;
    }
    
    if (!isValid) {
        const errorMessage = errors.join(', ');
        showNotification(errorMessage, 'error', 5000);
    }
    
    return isValid;
}

/**
 * Collect portfolio data from form
 */
function collectPortfolioData() {
    const portfolioName = document.getElementById('portfolio-name').value.trim();
    const investorName = document.getElementById('investor-name').value.trim();
    
    const stocks = [];
    let totalInvestment = 0;
    
    document.querySelectorAll('.stock-row').forEach(row => {
        const symbol = row.querySelector('.stock-symbol').value.trim().toUpperCase();
        const quantity = Number(row.querySelector('.stock-quantity').value);
        const price = Number(row.querySelector('.stock-price').value);
        
        if (symbol && quantity && price) {
            const investment = quantity * price;
            stocks.push({
                symbol: symbol,
                quantity: quantity,
                avg_price: price,
                investment: investment
            });
            totalInvestment += investment;
        }
    });
    
    return {
        id: generateId(),
        portfolio_name: portfolioName,
        user_name: investorName,
        stocks: stocks,
        total_investment: totalInvestment,
        created_date: new Date().toISOString(),
        last_analyzed: null
    };
}

/**
 * Save portfolio to database
 */
async function savePortfolio() {
    if (!validatePortfolioForm()) {
        return;
    }
    
    try {
        const portfolioData = collectPortfolioData();
        
        const response = await fetch(`${API_BASE}tables/portfolios`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(portfolioData)
        });
        
        if (response.ok) {
            const savedPortfolio = await response.json();
            currentPortfolio = savedPortfolio;
            
            showNotification('Portfolio saved successfully!', 'success');
            await loadSavedPortfolios();
        } else {
            throw new Error('Failed to save portfolio');
        }
    } catch (error) {
        console.error('❌ Error saving portfolio:', error);
        showNotification('Error saving portfolio. Please try again.', 'error');
    }
}

/**
 * Load saved portfolios
 */
async function loadSavedPortfolios() {
    try {
        const response = await fetch(`${API_BASE}tables/portfolios?search=${currentUser}&limit=10`);
        const result = await response.json();
        
        if (result.data && result.data.length > 0) {
            console.log(`✅ Loaded ${result.data.length} saved portfolios`);
            // You can implement portfolio history UI here
        }
    } catch (error) {
        console.error('❌ Error loading saved portfolios:', error);
    }
}

/**
 * Analyze portfolio - main function
 */
async function analyzePortfolio() {
    if (!validatePortfolioForm()) {
        return;
    }
    
    // Check credits
    const analysisCost = 10;
    if (userCredits < analysisCost) {
        showNotification('Insufficient credits! You need ₹10 to analyze your portfolio.', 'error');
        return;
    }
    
    try {
        // Disable analyze button
        const analyzeBtn = document.getElementById('analyze-btn');
        analyzeBtn.disabled = true;
        analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...';
        
        // Show progress sidebar
        showProgressSidebar();
        
        // Collect portfolio data
        const portfolioData = collectPortfolioData();
        currentPortfolio = portfolioData;
        
        // Deduct credits
        await deductCredits(analysisCost, 'PORTFOLIO_ANALYSIS', 
            `Analysis of portfolio: ${portfolioData.portfolio_name}`);
        
        // Start analysis process
        await performAnalysisSteps(portfolioData);
        
        // Save portfolio and analysis to database
        await savePortfolioAndAnalysis(portfolioData);
        
        // Show results
        showAnalysisResults();
        
    } catch (error) {
        console.error('❌ Error analyzing portfolio:', error);
        showNotification('Error analyzing portfolio. Please try again.', 'error');
    } finally {
        // Re-enable analyze button
        const analyzeBtn = document.getElementById('analyze-btn');
        analyzeBtn.disabled = false;
        analyzeBtn.innerHTML = '<i class="fas fa-chart-bar"></i> Analyze Portfolio (₹10)';
        
        hideProgressSidebar();
    }
}

/**
 * Show progress sidebar
 */
function showProgressSidebar() {
    const sidebar = document.getElementById('progress-sidebar');
    sidebar.classList.add('active');
    
    // Reset progress
    resetProgressSteps();
}

/**
 * Hide progress sidebar
 */
function hideProgressSidebar() {
    const sidebar = document.getElementById('progress-sidebar');
    setTimeout(() => {
        sidebar.classList.remove('active');
    }, 2000); // Keep visible for 2 seconds after completion
}

/**
 * Reset progress steps
 */
function resetProgressSteps() {
    document.querySelectorAll('.progress-step').forEach(step => {
        step.classList.remove('active', 'completed');
        step.querySelector('.step-status').textContent = 'Pending';
    });
    
    updateProgressBar(0);
}

/**
 * Update progress step
 */
function updateProgressStep(stepNumber, status) {
    const step = document.querySelector(`[data-step="${stepNumber}"]`);
    if (step) {
        step.classList.remove('active', 'completed');
        
        if (status === 'active') {
            step.classList.add('active');
            step.querySelector('.step-status').textContent = 'In Progress...';
        } else if (status === 'completed') {
            step.classList.add('completed');
            step.querySelector('.step-status').textContent = 'Completed';
        }
    }
    
    // Update overall progress
    const totalSteps = 4;
    const completedSteps = document.querySelectorAll('.progress-step.completed').length;
    const progress = (completedSteps / totalSteps) * 100;
    updateProgressBar(progress);
}

/**
 * Update progress bar
 */
function updateProgressBar(percentage) {
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-percentage');
    
    if (progressFill) {
        progressFill.style.width = `${percentage}%`;
    }
    
    if (progressText) {
        progressText.textContent = `${Math.round(percentage)}%`;
    }
}

/**
 * Perform analysis steps with progress tracking
 */
async function performAnalysisSteps(portfolioData) {
    analysisInProgress = true;
    
    // Step 1: Fetch live data
    updateProgressStep(1, 'active');
    await fetchLiveStockData(portfolioData.stocks);
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate processing time
    updateProgressStep(1, 'completed');
    
    // Step 2: Calculate metrics
    updateProgressStep(2, 'active');
    await calculatePortfolioMetrics(portfolioData);
    await new Promise(resolve => setTimeout(resolve, 1500));
    updateProgressStep(2, 'completed');
    
    // Step 3: AI Analysis
    updateProgressStep(3, 'active');
    await performAIAnalysis(portfolioData);
    await new Promise(resolve => setTimeout(resolve, 2000));
    updateProgressStep(3, 'completed');
    
    // Step 4: Generate report
    updateProgressStep(4, 'active');
    await generateAnalysisReport(portfolioData);
    await new Promise(resolve => setTimeout(resolve, 1000));
    updateProgressStep(4, 'completed');
    
    analysisInProgress = false;
}

/**
 * Fetch live stock data
 */
async function fetchLiveStockData(stocks) {
    for (const stock of stocks) {
        try {
            const response = await fetch(`${API_BASE}tables/stock_data?search=${stock.symbol}&limit=1`);
            const result = await response.json();
            
            if (result.data && result.data.length > 0) {
                const stockData = result.data[0];
                stock.current_price = stockData.current_price;
                stock.day_change = stockData.day_change;
                stock.company_name = stockData.company_name;
                stock.sector = stockData.sector;
                stock.pe_ratio = stockData.pe_ratio;
                stock.market_cap = stockData.market_cap;
                
                // Calculate current value and P&L
                stock.current_value = stock.quantity * stock.current_price;
                stock.investment_value = stock.quantity * stock.avg_price;
                stock.pnl = stock.current_value - stock.investment_value;
                stock.pnl_percentage = (stock.pnl / stock.investment_value) * 100;
            }
        } catch (error) {
            console.error(`❌ Error fetching data for ${stock.symbol}:`, error);
            // Use fallback data if API fails
            stock.current_price = stock.avg_price * (1 + (Math.random() - 0.5) * 0.1);
            stock.current_value = stock.quantity * stock.current_price;
            stock.pnl = stock.current_value - (stock.quantity * stock.avg_price);
            stock.pnl_percentage = (stock.pnl / (stock.quantity * stock.avg_price)) * 100;
        }
    }
}

/**
 * Calculate portfolio metrics
 */
async function calculatePortfolioMetrics(portfolioData) {
    let totalCurrentValue = 0;
    let totalInvestment = 0;
    let totalPnL = 0;
    
    const sectorAllocation = {};
    const riskMetrics = {
        low: 0,
        medium: 0,
        high: 0
    };
    
    portfolioData.stocks.forEach(stock => {
        totalCurrentValue += stock.current_value || (stock.quantity * stock.avg_price);
        totalInvestment += stock.quantity * stock.avg_price;
        totalPnL += stock.pnl || 0;
        
        // Sector allocation
        const sector = stock.sector || 'Unknown';
        if (!sectorAllocation[sector]) {
            sectorAllocation[sector] = 0;
        }
        sectorAllocation[sector] += stock.current_value || (stock.quantity * stock.avg_price);
        
        // Risk assessment based on sector and PE ratio
        const peRatio = stock.pe_ratio || 20;
        if (peRatio < 15 || ['Banking', 'FMCG'].includes(sector)) {
            riskMetrics.low += stock.current_value || (stock.quantity * stock.avg_price);
        } else if (peRatio > 30 || ['Information Technology'].includes(sector)) {
            riskMetrics.high += stock.current_value || (stock.quantity * stock.avg_price);
        } else {
            riskMetrics.medium += stock.current_value || (stock.quantity * stock.avg_price);
        }
    });
    
    portfolioData.metrics = {
        totalCurrentValue,
        totalInvestment,
        totalPnL,
        pnlPercentage: (totalPnL / totalInvestment) * 100,
        sectorAllocation,
        riskMetrics
    };
}

/**
 * Perform AI Analysis and generate recommendations
 */
async function performAIAnalysis(portfolioData) {
    const recommendations = [];
    const stocks = portfolioData.stocks;
    const metrics = portfolioData.metrics;
    
    // Analyze individual stocks
    stocks.forEach(stock => {
        const pnlPercentage = stock.pnl_percentage || 0;
        const peRatio = stock.pe_ratio || 20;
        
        let recommendation, reason, riskLevel;
        
        // Simple AI logic for recommendations
        if (pnlPercentage < -15) {
            recommendation = 'SELL';
            reason = `${stock.symbol} has declined significantly (${pnlPercentage.toFixed(1)}%). Consider cutting losses if fundamentals have weakened.`;
            riskLevel = 'HIGH';
        } else if (pnlPercentage > 25) {
            recommendation = 'HOLD';
            reason = `${stock.symbol} has performed well (${pnlPercentage.toFixed(1)}% gain). Consider booking partial profits or holding for long term.`;
            riskLevel = 'MEDIUM';
        } else if (peRatio > 40) {
            recommendation = 'SELL';
            reason = `${stock.symbol} appears overvalued with PE ratio of ${peRatio.toFixed(1)}. Consider reducing exposure.`;
            riskLevel = 'HIGH';
        } else if (peRatio < 12 && ['Banking', 'FMCG'].includes(stock.sector)) {
            recommendation = 'BUY';
            reason = `${stock.symbol} looks undervalued with PE ratio of ${peRatio.toFixed(1)}. Good opportunity to accumulate.`;
            riskLevel = 'LOW';
        } else {
            recommendation = 'HOLD';
            reason = `${stock.symbol} is fairly valued. Maintain current position and monitor performance.`;
            riskLevel = 'MEDIUM';
        }
        
        recommendations.push({
            stock_symbol: stock.symbol,
            recommendation,
            reason,
            risk_level: riskLevel,
            current_price: stock.current_price || stock.avg_price,
            target_price: stock.current_price ? stock.current_price * (1 + (Math.random() - 0.5) * 0.2) : stock.avg_price
        });
    });
    
    // Portfolio-level recommendations
    const sectorCount = Object.keys(metrics.sectorAllocation).length;
    if (sectorCount < 3) {
        recommendations.push({
            stock_symbol: 'PORTFOLIO',
            recommendation: 'DIVERSIFY',
            reason: 'Your portfolio lacks diversification. Consider adding stocks from different sectors like Healthcare, Automobiles, or Consumer Goods.',
            risk_level: 'HIGH',
            current_price: 0,
            target_price: 0
        });
    }
    
    // Risk assessment
    const highRiskPercentage = (metrics.riskMetrics.high / metrics.totalCurrentValue) * 100;
    if (highRiskPercentage > 50) {
        recommendations.push({
            stock_symbol: 'PORTFOLIO',
            recommendation: 'DIVERSIFY',
            reason: `${highRiskPercentage.toFixed(1)}% of your portfolio is in high-risk stocks. Consider rebalancing with safer options.`,
            risk_level: 'HIGH',
            current_price: 0,
            target_price: 0
        });
    }
    
    portfolioData.recommendations = recommendations;
    portfolioData.portfolioScore = calculatePortfolioScore(portfolioData);
}

/**
 * Calculate portfolio score
 */
function calculatePortfolioScore(portfolioData) {
    let score = 5.0; // Base score
    
    const metrics = portfolioData.metrics;
    
    // Diversification bonus
    const sectorCount = Object.keys(metrics.sectorAllocation).length;
    if (sectorCount >= 4) score += 1.5;
    else if (sectorCount >= 3) score += 1.0;
    else if (sectorCount >= 2) score += 0.5;
    
    // Performance bonus/penalty
    if (metrics.pnlPercentage > 15) score += 1.0;
    else if (metrics.pnlPercentage > 5) score += 0.5;
    else if (metrics.pnlPercentage < -10) score -= 1.0;
    else if (metrics.pnlPercentage < -5) score -= 0.5;
    
    // Risk assessment
    const highRiskPercentage = (metrics.riskMetrics.high / metrics.totalCurrentValue) * 100;
    if (highRiskPercentage < 30) score += 0.5;
    else if (highRiskPercentage > 70) score -= 1.0;
    
    return Math.min(Math.max(score, 1.0), 10.0); // Clamp between 1-10
}

/**
 * Generate analysis report
 */
async function generateAnalysisReport(portfolioData) {
    // Save individual stock analyses
    for (const rec of portfolioData.recommendations) {
        try {
            const analysisData = {
                portfolio_id: portfolioData.id,
                stock_symbol: rec.stock_symbol,
                recommendation: rec.recommendation,
                reason: rec.reason,
                risk_level: rec.risk_level,
                current_price: rec.current_price,
                target_price: rec.target_price,
                analysis_date: new Date().toISOString()
            };
            
            await fetch(`${API_BASE}tables/stock_analyses`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(analysisData)
            });
        } catch (error) {
            console.error('❌ Error saving analysis:', error);
        }
    }
}

/**
 * Save portfolio and analysis to database
 */
async function savePortfolioAndAnalysis(portfolioData) {
    try {
        // Update last analyzed time
        portfolioData.last_analyzed = new Date().toISOString();
        
        // Save portfolio
        await fetch(`${API_BASE}tables/portfolios`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(portfolioData)
        });
        
        console.log('✅ Portfolio and analysis saved successfully');
    } catch (error) {
        console.error('❌ Error saving portfolio:', error);
    }
}

/**
 * Analyze new portfolio (reset form)
 */
function analyzeNewPortfolio() {
    // Reset form
    document.getElementById('portfolio-name').value = '';
    document.getElementById('investor-name').value = '';
    
    // Clear stock rows except first one
    const container = document.getElementById('stocks-container');
    while (container.children.length > 1) {
        container.removeChild(container.lastChild);
    }
    
    // Clear first row
    const firstRow = container.querySelector('.stock-row');
    firstRow.querySelector('.stock-symbol').value = '';
    firstRow.querySelector('.stock-quantity').value = '';
    firstRow.querySelector('.stock-price').value = '';
    
    // Hide analysis section
    document.getElementById('analysis').style.display = 'none';
    
    // Scroll to portfolio section
    scrollToSection('portfolio');
    
    showNotification('Ready for new portfolio analysis', 'info');
}