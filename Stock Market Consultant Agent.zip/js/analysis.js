// Analysis and Visualization JavaScript
// Handles displaying analysis results, charts, and recommendations

let portfolioChart = null;
let riskChart = null;
let sectorChart = null;

/**
 * Show analysis results section
 */
function showAnalysisResults() {
    if (!currentPortfolio || !currentPortfolio.recommendations) {
        showNotification('No analysis data available', 'error');
        return;
    }
    
    // Show analysis section
    const analysisSection = document.getElementById('analysis');
    analysisSection.style.display = 'block';
    
    // Update analysis date
    const analysisDate = document.getElementById('analysis-date');
    if (analysisDate) {
        analysisDate.textContent = `Analysis completed on ${formatDate(new Date().toISOString())}`;
    }
    
    // Display portfolio overview
    displayPortfolioOverview();
    
    // Display recommendations
    displayRecommendations();
    
    // Display risk analysis
    displayRiskAnalysis();
    
    // Display sector allocation
    displaySectorAllocation();
    
    // Scroll to analysis section
    setTimeout(() => {
        scrollToSection('analysis');
    }, 500);
    
    showNotification('Analysis completed successfully!', 'success');
}

/**
 * Display portfolio overview with chart
 */
function displayPortfolioOverview() {
    const metrics = currentPortfolio.metrics;
    
    // Update portfolio value
    const valueElement = document.getElementById('portfolio-value');
    if (valueElement) {
        valueElement.textContent = formatCurrency(metrics.totalCurrentValue);
    }
    
    // Update portfolio change
    const changeElement = document.getElementById('portfolio-change');
    if (changeElement) {
        const changePercentage = metrics.pnlPercentage;
        changeElement.textContent = `${changePercentage >= 0 ? '+' : ''}${changePercentage.toFixed(2)}%`;
        changeElement.className = `value-change ${changePercentage >= 0 ? 'positive' : 'negative'}`;
    }
    
    // Update portfolio score
    const scoreElement = document.getElementById('portfolio-score');
    if (scoreElement) {
        scoreElement.textContent = `${currentPortfolio.portfolioScore.toFixed(1)}/10`;
    }
    
    // Create portfolio performance chart
    createPortfolioChart();
}

/**
 * Create portfolio performance chart
 */
function createPortfolioChart() {
    const ctx = document.getElementById('portfolio-chart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (portfolioChart) {
        portfolioChart.destroy();
    }
    
    const stocks = currentPortfolio.stocks;
    
    const chartData = {
        labels: stocks.map(stock => stock.symbol),
        datasets: [{
            label: 'Current Value',
            data: stocks.map(stock => stock.current_value || (stock.quantity * stock.avg_price)),
            backgroundColor: stocks.map(() => getRandomColor() + '80'),
            borderColor: stocks.map(() => getRandomColor()),
            borderWidth: 2
        }]
    };
    
    portfolioChart = new Chart(ctx, {
        type: 'doughnut',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${context.label}: ${formatCurrency(value)} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Display recommendations
 */
function displayRecommendations() {
    const recommendationsList = document.getElementById('recommendations-list');
    if (!recommendationsList) return;
    
    recommendationsList.innerHTML = '';
    
    currentPortfolio.recommendations.forEach((rec, index) => {
        const recElement = document.createElement('div');
        recElement.className = `recommendation-item ${rec.recommendation.toLowerCase()}`;
        
        let actionIcon = '';
        switch (rec.recommendation) {
            case 'BUY': actionIcon = 'fas fa-arrow-up'; break;
            case 'SELL': actionIcon = 'fas fa-arrow-down'; break;
            case 'HOLD': actionIcon = 'fas fa-hand-paper'; break;
            case 'DIVERSIFY': actionIcon = 'fas fa-expand-arrows-alt'; break;
        }
        
        recElement.innerHTML = `
            <div class="recommendation-header">
                <div class="recommendation-action">
                    <i class="${actionIcon}"></i>
                    ${rec.stock_symbol !== 'PORTFOLIO' ? rec.stock_symbol : 'Portfolio'} - ${rec.recommendation}
                </div>
                <div class="recommendation-tag">${rec.risk_level}</div>
            </div>
            <div class="recommendation-text">${rec.reason}</div>
        `;
        
        // Animation delay
        recElement.style.animationDelay = `${index * 0.1}s`;
        
        recommendationsList.appendChild(recElement);
    });
}

/**
 * Display risk analysis
 */
function displayRiskAnalysis() {
    const riskBreakdown = document.getElementById('risk-breakdown');
    if (!riskBreakdown) return;
    
    const metrics = currentPortfolio.metrics;
    const totalValue = metrics.totalCurrentValue;
    
    const lowRiskPercentage = (metrics.riskMetrics.low / totalValue) * 100;
    const mediumRiskPercentage = (metrics.riskMetrics.medium / totalValue) * 100;
    const highRiskPercentage = (metrics.riskMetrics.high / totalValue) * 100;
    
    riskBreakdown.innerHTML = `
        <div class="risk-item">
            <div class="risk-label">
                <span class="risk-color low-risk"></span>
                Low Risk
            </div>
            <div class="risk-value">${lowRiskPercentage.toFixed(1)}%</div>
        </div>
        <div class="risk-item">
            <div class="risk-label">
                <span class="risk-color medium-risk"></span>
                Medium Risk
            </div>
            <div class="risk-value">${mediumRiskPercentage.toFixed(1)}%</div>
        </div>
        <div class="risk-item">
            <div class="risk-label">
                <span class="risk-color high-risk"></span>
                High Risk
            </div>
            <div class="risk-value">${highRiskPercentage.toFixed(1)}%</div>
        </div>
    `;
    
    // Add CSS for risk colors if not already added
    if (!document.getElementById('risk-colors-style')) {
        const style = document.createElement('style');
        style.id = 'risk-colors-style';
        style.textContent = `
            .risk-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: var(--space-md);
                margin-bottom: var(--space-sm);
                background: var(--bg-tertiary);
                border-radius: var(--radius-md);
            }
            .risk-label {
                display: flex;
                align-items: center;
                gap: var(--space-sm);
                font-weight: 600;
            }
            .risk-color {
                width: 12px;
                height: 12px;
                border-radius: 50%;
            }
            .low-risk { background: var(--success-color); }
            .medium-risk { background: var(--warning-color); }
            .high-risk { background: var(--danger-color); }
            .risk-value {
                font-weight: 700;
                color: var(--text-primary);
            }
        `;
        document.head.appendChild(style);
    }
    
    // Create risk gauge chart
    createRiskChart(lowRiskPercentage, mediumRiskPercentage, highRiskPercentage);
}

/**
 * Create risk gauge chart
 */
function createRiskChart(lowRisk, mediumRisk, highRisk) {
    const ctx = document.getElementById('risk-chart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (riskChart) {
        riskChart.destroy();
    }
    
    riskChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Low Risk', 'Medium Risk', 'High Risk'],
            datasets: [{
                data: [lowRisk, mediumRisk, highRisk],
                backgroundColor: [
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(245, 158, 11, 0.8)',
                    'rgba(239, 68, 68, 0.8)'
                ],
                borderColor: [
                    'rgba(16, 185, 129, 1)',
                    'rgba(245, 158, 11, 1)',
                    'rgba(239, 68, 68, 1)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '60%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${context.parsed.toFixed(1)}%`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Display sector allocation
 */
function displaySectorAllocation() {
    const ctx = document.getElementById('sector-chart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (sectorChart) {
        sectorChart.destroy();
    }
    
    const sectorAllocation = currentPortfolio.metrics.sectorAllocation;
    const sectors = Object.keys(sectorAllocation);
    const values = Object.values(sectorAllocation);
    
    const colors = sectors.map(() => getRandomColor());
    
    sectorChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: sectors,
            datasets: [{
                label: 'Sector Allocation',
                data: values,
                backgroundColor: colors.map(color => color + '80'),
                borderColor: colors,
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed.y;
                            const total = values.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${formatCurrency(value)} (${percentage}%)`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return formatLargeNumber(value);
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                }
            }
        }
    });
}

/**
 * Generate detailed report
 */
async function generateDetailedReport() {
    const reportCost = 5;
    
    // Check credits
    if (!await deductCredits(reportCost, 'REPORT_GENERATED', 'Detailed Portfolio Report')) {
        return;
    }
    
    // Show loading
    showNotification('Generating detailed report...', 'info', 2000);
    
    // Simulate report generation
    setTimeout(() => {
        const reportContent = createDetailedReportContent();
        showDetailedReportModal(reportContent);
        showNotification('Detailed report generated successfully!', 'success');
    }, 2000);
}

/**
 * Create detailed report content
 */
function createDetailedReportContent() {
    const portfolio = currentPortfolio;
    const metrics = portfolio.metrics;
    
    let reportHTML = `
        <div class="detailed-report">
            <div class="report-header">
                <h2>${portfolio.portfolio_name} - Detailed Analysis Report</h2>
                <div class="report-meta">
                    <p>Investor: ${portfolio.user_name}</p>
                    <p>Analysis Date: ${formatDate(new Date().toISOString())}</p>
                    <p>Portfolio Score: ${portfolio.portfolioScore.toFixed(1)}/10</p>
                </div>
            </div>
            
            <div class="report-section">
                <h3>Executive Summary</h3>
                <div class="summary-grid">
                    <div class="summary-item">
                        <div class="summary-label">Total Investment</div>
                        <div class="summary-value">${formatCurrency(metrics.totalInvestment)}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Current Value</div>
                        <div class="summary-value">${formatCurrency(metrics.totalCurrentValue)}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Total P&L</div>
                        <div class="summary-value ${metrics.totalPnL >= 0 ? 'positive' : 'negative'}">
                            ${formatCurrency(metrics.totalPnL)} (${metrics.pnlPercentage.toFixed(2)}%)
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="report-section">
                <h3>Stock-wise Analysis</h3>
                <table class="stock-analysis-table">
                    <thead>
                        <tr>
                            <th>Stock</th>
                            <th>Quantity</th>
                            <th>Avg Price</th>
                            <th>Current Price</th>
                            <th>Investment</th>
                            <th>Current Value</th>
                            <th>P&L</th>
                            <th>Recommendation</th>
                        </tr>
                    </thead>
                    <tbody>
    `;
    
    portfolio.stocks.forEach(stock => {
        const recommendation = portfolio.recommendations.find(r => r.stock_symbol === stock.symbol);
        const pnlClass = (stock.pnl || 0) >= 0 ? 'positive' : 'negative';
        
        reportHTML += `
            <tr>
                <td><strong>${stock.symbol}</strong></td>
                <td>${stock.quantity}</td>
                <td>₹${stock.avg_price.toFixed(2)}</td>
                <td>₹${(stock.current_price || stock.avg_price).toFixed(2)}</td>
                <td>${formatCurrency(stock.quantity * stock.avg_price)}</td>
                <td>${formatCurrency(stock.current_value || (stock.quantity * stock.avg_price))}</td>
                <td class="${pnlClass}">
                    ${formatCurrency(stock.pnl || 0)} 
                    (${(stock.pnl_percentage || 0).toFixed(2)}%)
                </td>
                <td class="recommendation-${(recommendation?.recommendation || 'HOLD').toLowerCase()}">
                    ${recommendation?.recommendation || 'HOLD'}
                </td>
            </tr>
        `;
    });
    
    reportHTML += `
                    </tbody>
                </table>
            </div>
            
            <div class="report-section">
                <h3>Recommendations</h3>
                <div class="recommendations-detailed">
    `;
    
    portfolio.recommendations.forEach(rec => {
        reportHTML += `
            <div class="recommendation-detailed ${rec.recommendation.toLowerCase()}">
                <h4>${rec.stock_symbol} - ${rec.recommendation}</h4>
                <p>${rec.reason}</p>
                <div class="rec-meta">
                    <span>Risk Level: ${rec.risk_level}</span>
                    ${rec.target_price > 0 ? `<span>Target Price: ₹${rec.target_price.toFixed(2)}</span>` : ''}
                </div>
            </div>
        `;
    });
    
    reportHTML += `
                </div>
            </div>
            
            <div class="report-section">
                <h3>Risk Assessment</h3>
                <div class="risk-detailed">
                    <p>Your portfolio risk distribution:</p>
                    <ul>
                        <li>Low Risk: ${((metrics.riskMetrics.low / metrics.totalCurrentValue) * 100).toFixed(1)}%</li>
                        <li>Medium Risk: ${((metrics.riskMetrics.medium / metrics.totalCurrentValue) * 100).toFixed(1)}%</li>
                        <li>High Risk: ${((metrics.riskMetrics.high / metrics.totalCurrentValue) * 100).toFixed(1)}%</li>
                    </ul>
                </div>
            </div>
            
            <div class="report-footer">
                <p><strong>Disclaimer:</strong> This analysis is for educational purposes only and should not be considered as investment advice. Please consult with a qualified financial advisor before making investment decisions.</p>
            </div>
        </div>
    `;
    
    return reportHTML;
}

/**
 * Show detailed report in modal
 */
function showDetailedReportModal(content) {
    // Create modal
    const modal = document.createElement('div');
    modal.className = 'report-modal';
    modal.innerHTML = `
        <div class="modal-overlay"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3>Detailed Portfolio Report</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="printReport()">
                    <i class="fas fa-print"></i> Print Report
                </button>
                <button class="btn-primary" onclick="downloadReport()">
                    <i class="fas fa-download"></i> Download PDF
                </button>
            </div>
        </div>
    `;
    
    // Add modal styles
    const modalStyle = document.createElement('style');
    modalStyle.textContent = `
        .report-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
        }
        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            max-width: 90vw;
            max-height: 90vh;
            width: 800px;
            position: relative;
            z-index: 10001;
            display: flex;
            flex-direction: column;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: var(--space-xl);
            border-bottom: 1px solid var(--gray-200);
        }
        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--gray-500);
        }
        .modal-body {
            padding: var(--space-xl);
            overflow-y: auto;
            flex: 1;
        }
        .modal-footer {
            display: flex;
            gap: var(--space-md);
            justify-content: flex-end;
            padding: var(--space-xl);
            border-top: 1px solid var(--gray-200);
        }
        .detailed-report h3 {
            color: var(--primary-color);
            margin-top: var(--space-xl);
            margin-bottom: var(--space-md);
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: var(--space-md);
            margin-bottom: var(--space-lg);
        }
        .summary-item {
            background: var(--bg-tertiary);
            padding: var(--space-md);
            border-radius: var(--radius-md);
            text-align: center;
        }
        .summary-label {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-bottom: var(--space-xs);
        }
        .summary-value {
            font-size: 1.25rem;
            font-weight: 700;
        }
        .summary-value.positive { color: var(--success-color); }
        .summary-value.negative { color: var(--danger-color); }
        .stock-analysis-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: var(--space-lg);
        }
        .stock-analysis-table th,
        .stock-analysis-table td {
            padding: var(--space-sm);
            border: 1px solid var(--gray-200);
            text-align: left;
        }
        .stock-analysis-table th {
            background: var(--bg-tertiary);
            font-weight: 600;
        }
        .stock-analysis-table .positive { color: var(--success-color); }
        .stock-analysis-table .negative { color: var(--danger-color); }
        .recommendation-buy { color: var(--success-color); font-weight: 600; }
        .recommendation-sell { color: var(--danger-color); font-weight: 600; }
        .recommendation-hold { color: var(--warning-color); font-weight: 600; }
        .recommendation-diversify { color: var(--info-color); font-weight: 600; }
        .recommendations-detailed {
            display: flex;
            flex-direction: column;
            gap: var(--space-md);
        }
        .recommendation-detailed {
            padding: var(--space-md);
            border-radius: var(--radius-md);
            border-left: 4px solid;
        }
        .recommendation-detailed.buy { background: rgba(16, 185, 129, 0.1); border-color: var(--success-color); }
        .recommendation-detailed.sell { background: rgba(239, 68, 68, 0.1); border-color: var(--danger-color); }
        .recommendation-detailed.hold { background: rgba(245, 158, 11, 0.1); border-color: var(--warning-color); }
        .recommendation-detailed.diversify { background: rgba(59, 130, 246, 0.1); border-color: var(--info-color); }
        .rec-meta {
            display: flex;
            gap: var(--space-md);
            margin-top: var(--space-sm);
            font-size: 0.875rem;
            color: var(--text-secondary);
        }
    `;
    document.head.appendChild(modalStyle);
    
    // Add to DOM
    document.body.appendChild(modal);
    
    // Close modal functionality
    const closeModal = () => {
        document.body.removeChild(modal);
        document.head.removeChild(modalStyle);
    };
    
    modal.querySelector('.modal-close').addEventListener('click', closeModal);
    modal.querySelector('.modal-overlay').addEventListener('click', closeModal);
}

/**
 * Print report
 */
function printReport() {
    const reportContent = document.querySelector('.detailed-report');
    if (reportContent) {
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Portfolio Analysis Report</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    .report-header h2 { color: #2563eb; }
                    table { border-collapse: collapse; width: 100%; margin: 20px 0; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    .positive { color: #10b981; }
                    .negative { color: #ef4444; }
                </style>
            </head>
            <body>
                ${reportContent.outerHTML}
            </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    }
}

/**
 * Download report (placeholder)
 */
function downloadReport() {
    showNotification('PDF download functionality will be available soon!', 'info');
}

/**
 * Share analysis
 */
function shareAnalysis() {
    if (navigator.share) {
        navigator.share({
            title: 'My Portfolio Analysis',
            text: `Check out my portfolio analysis results! Overall score: ${currentPortfolio.portfolioScore.toFixed(1)}/10`,
            url: window.location.href
        }).then(() => {
            showNotification('Analysis shared successfully!', 'success');
        }).catch(() => {
            fallbackShare();
        });
    } else {
        fallbackShare();
    }
}

/**
 * Fallback share functionality
 */
function fallbackShare() {
    const shareText = `Check out my portfolio analysis results! Overall score: ${currentPortfolio.portfolioScore.toFixed(1)}/10\n\nAnalyzed with StockConsultant Agent: ${window.location.href}`;
    
    if (navigator.clipboard) {
        navigator.clipboard.writeText(shareText).then(() => {
            showNotification('Share text copied to clipboard!', 'success');
        });
    } else {
        // Create temporary textarea for copying
        const textArea = document.createElement('textarea');
        textArea.value = shareText;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showNotification('Share text copied to clipboard!', 'success');
    }
}