// Main JavaScript for Stock Consultant Agent
// Global variables and utilities

let currentUser = 'demo_user';
let userCredits = 100;
let currentPortfolio = null;
let analysisInProgress = false;

// API Base URL for RESTful endpoints
const API_BASE = '';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    initializeHeroChart();
    loadUserData();
    setupEventListeners();
});

/**
 * Initialize the application
 */
function initializeApp() {
    console.log('🚀 Stock Consultant Agent initialized');
    
    // Update UI with user data
    updateCreditsDisplay();
    
    // Initialize mock stock data if not exists
    initializeMockStockData();
    
    // Load saved portfolios
    loadSavedPortfolios();
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href').substring(1);
            scrollToSection(target);
            updateActiveNavLink(this);
        });
    });
    
    // Form inputs
    setupFormValidation();
    
    // Real-time stock symbol suggestions
    setupStockSuggestions();
}

/**
 * Update active navigation link
 */
function updateActiveNavLink(activeLink) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    activeLink.classList.add('active');
}

/**
 * Smooth scroll to section
 */
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

/**
 * Update credits display
 */
function updateCreditsDisplay() {
    const creditsElement = document.getElementById('user-credits');
    if (creditsElement) {
        creditsElement.textContent = userCredits;
    }
}

/**
 * Deduct credits for actions
 */
async function deductCredits(amount, actionType, details = '') {
    if (userCredits >= amount) {
        userCredits -= amount;
        updateCreditsDisplay();
        
        // Record usage
        await recordUsage(actionType, amount, details);
        
        return true;
    } else {
        showNotification('Insufficient credits! Please purchase more credits to continue.', 'error');
        return false;
    }
}

/**
 * Record usage in the database
 */
async function recordUsage(actionType, cost, details = '') {
    try {
        const usageData = {
            user_name: currentUser,
            action_type: actionType,
            cost: cost,
            timestamp: new Date().toISOString(),
            details: details
        };
        
        if (currentPortfolio) {
            usageData.portfolio_id = currentPortfolio.id;
        }
        
        const response = await fetch(`${API_BASE}tables/usage_tracking`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(usageData)
        });
        
        if (response.ok) {
            console.log('✅ Usage recorded successfully');
            await loadUsageStats();
        }
    } catch (error) {
        console.error('❌ Error recording usage:', error);
    }
}

/**
 * Initialize hero chart
 */
function initializeHeroChart() {
    const ctx = document.getElementById('hero-chart');
    if (!ctx) return;
    
    const chartCtx = ctx.getContext('2d');
    
    // Sample data for hero chart
    const heroChart = new Chart(chartCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Portfolio Value',
                data: [100000, 108000, 112000, 106000, 118000, 125000],
                borderColor: 'rgba(255, 255, 255, 0.8)',
                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: 'white',
                pointBorderColor: 'rgba(255, 255, 255, 0.8)',
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    display: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                },
                y: {
                    display: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        callback: function(value) {
                            return '₹' + (value / 1000) + 'K';
                        }
                    }
                }
            },
            elements: {
                point: {
                    hoverRadius: 6
                }
            }
        }
    });
}

/**
 * Initialize mock stock data
 */
async function initializeMockStockData() {
    try {
        // Check if stock data already exists
        const response = await fetch(`${API_BASE}tables/stock_data?limit=1`);
        const result = await response.json();
        
        if (result.data && result.data.length > 0) {
            console.log('✅ Stock data already exists');
            return;
        }
        
        // Create mock stock data
        const mockStocks = [
            {
                symbol: 'TCS',
                company_name: 'Tata Consultancy Services',
                current_price: 3420.75,
                day_change: 2.5,
                market_cap: 1250000000000,
                pe_ratio: 28.5,
                sector: 'Information Technology',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'INFY',
                company_name: 'Infosys Limited',
                current_price: 1456.30,
                day_change: -1.2,
                market_cap: 620000000000,
                pe_ratio: 24.8,
                sector: 'Information Technology',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'HDFCBANK',
                company_name: 'HDFC Bank Limited',
                current_price: 1642.85,
                day_change: 0.8,
                market_cap: 1200000000000,
                pe_ratio: 19.2,
                sector: 'Banking',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'RELIANCE',
                company_name: 'Reliance Industries Limited',
                current_price: 2456.90,
                day_change: 1.5,
                market_cap: 1650000000000,
                pe_ratio: 22.1,
                sector: 'Oil & Gas',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'ITC',
                company_name: 'ITC Limited',
                current_price: 412.50,
                day_change: -0.5,
                market_cap: 510000000000,
                pe_ratio: 28.9,
                sector: 'FMCG',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'SBIN',
                company_name: 'State Bank of India',
                current_price: 598.75,
                day_change: 2.1,
                market_cap: 534000000000,
                pe_ratio: 12.4,
                sector: 'Banking',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'BHARTIARTL',
                company_name: 'Bharti Airtel Limited',
                current_price: 1078.45,
                day_change: 1.8,
                market_cap: 612000000000,
                pe_ratio: 35.6,
                sector: 'Telecommunications',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'KOTAKBANK',
                company_name: 'Kotak Mahindra Bank Limited',
                current_price: 1789.30,
                day_change: -0.3,
                market_cap: 356000000000,
                pe_ratio: 16.8,
                sector: 'Banking',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'LT',
                company_name: 'Larsen & Toubro Limited',
                current_price: 3254.60,
                day_change: 1.2,
                market_cap: 458000000000,
                pe_ratio: 31.5,
                sector: 'Construction',
                last_updated: new Date().toISOString()
            },
            {
                symbol: 'ASIANPAINT',
                company_name: 'Asian Paints Limited',
                current_price: 2987.80,
                day_change: -0.8,
                market_cap: 287000000000,
                pe_ratio: 52.3,
                sector: 'Paints & Varnishes',
                last_updated: new Date().toISOString()
            }
        ];
        
        // Insert mock data
        for (const stock of mockStocks) {
            await fetch(`${API_BASE}tables/stock_data`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(stock)
            });
        }
        
        console.log('✅ Mock stock data initialized');
    } catch (error) {
        console.error('❌ Error initializing mock stock data:', error);
    }
}

/**
 * Load user data
 */
async function loadUserData() {
    try {
        await loadUsageStats();
        await loadSavedPortfolios();
    } catch (error) {
        console.error('❌ Error loading user data:', error);
    }
}

/**
 * Setup form validation
 */
function setupFormValidation() {
    const inputs = document.querySelectorAll('.form-input, .stock-symbol, .stock-quantity, .stock-price');
    
    inputs.forEach(input => {
        input.addEventListener('blur', validateInput);
        input.addEventListener('input', clearValidationError);
    });
}

/**
 * Validate individual input
 */
function validateInput(event) {
    const input = event.target;
    const value = input.value.trim();
    
    // Remove existing error styles
    input.classList.remove('error');
    
    // Validate based on input type
    if (input.classList.contains('stock-symbol')) {
        if (value && !isValidStockSymbol(value)) {
            showInputError(input, 'Please enter a valid stock symbol');
        }
    } else if (input.classList.contains('stock-quantity')) {
        if (value && (!Number.isInteger(Number(value)) || Number(value) <= 0)) {
            showInputError(input, 'Please enter a valid quantity');
        }
    } else if (input.classList.contains('stock-price')) {
        if (value && (isNaN(Number(value)) || Number(value) <= 0)) {
            showInputError(input, 'Please enter a valid price');
        }
    }
}

/**
 * Clear validation error
 */
function clearValidationError(event) {
    const input = event.target;
    input.classList.remove('error');
    
    // Remove error message if exists
    const errorMsg = input.parentNode.querySelector('.error-message');
    if (errorMsg) {
        errorMsg.remove();
    }
}

/**
 * Show input error
 */
function showInputError(input, message) {
    input.classList.add('error');
    
    // Remove existing error message
    const existingError = input.parentNode.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    // Add error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    errorDiv.style.color = 'var(--danger-color)';
    errorDiv.style.fontSize = '0.875rem';
    errorDiv.style.marginTop = '0.25rem';
    
    input.parentNode.appendChild(errorDiv);
}

/**
 * Validate stock symbol format
 */
function isValidStockSymbol(symbol) {
    // Basic validation - alphanumeric, 2-10 characters
    return /^[A-Z0-9]{2,10}$/i.test(symbol);
}

/**
 * Setup stock symbol suggestions
 */
function setupStockSuggestions() {
    const stockInputs = document.querySelectorAll('.stock-symbol');
    
    stockInputs.forEach(input => {
        input.addEventListener('input', async function() {
            const query = this.value.toUpperCase();
            if (query.length >= 2) {
                await updateStockSuggestions(query);
            }
        });
    });
}

/**
 * Update stock suggestions datalist
 */
async function updateStockSuggestions(query) {
    try {
        const response = await fetch(`${API_BASE}tables/stock_data?search=${query}&limit=10`);
        const result = await response.json();
        
        if (result.data) {
            const datalist = document.getElementById('stock-suggestions');
            datalist.innerHTML = '';
            
            result.data.forEach(stock => {
                const option = document.createElement('option');
                option.value = stock.symbol;
                option.textContent = `${stock.symbol} - ${stock.company_name}`;
                datalist.appendChild(option);
            });
        }
    } catch (error) {
        console.error('❌ Error fetching stock suggestions:', error);
    }
}

/**
 * Show notification to user
 */
function showNotification(message, type = 'info', duration = 5000) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close">&times;</button>
        </div>
    `;
    
    // Add styles
    Object.assign(notification.style, {
        position: 'fixed',
        top: '100px',
        right: '20px',
        background: type === 'error' ? 'var(--danger-color)' : 
                   type === 'success' ? 'var(--success-color)' : 
                   type === 'warning' ? 'var(--warning-color)' : 'var(--info-color)',
        color: 'white',
        padding: '1rem 1.5rem',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--shadow-lg)',
        zIndex: '10000',
        maxWidth: '400px',
        animation: 'slideInRight 0.3s ease-out'
    });
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Auto remove
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-out forwards';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, duration);
    
    // Manual close
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.style.animation = 'slideOutRight 0.3s ease-out forwards';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    });
}

/**
 * Format currency
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

/**
 * Format large numbers
 */
function formatLargeNumber(num) {
    if (num >= 10000000) {
        return (num / 10000000).toFixed(1) + ' Cr';
    } else if (num >= 100000) {
        return (num / 100000).toFixed(1) + ' L';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

/**
 * Get random color from palette
 */
function getRandomColor() {
    const colors = [
        '#2563eb', '#10b981', '#f59e0b', '#ef4444', 
        '#8b5cf6', '#06b6d4', '#84cc16', '#f97316',
        '#ec4899', '#6366f1', '#14b8a6', '#eab308'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
}

/**
 * Show demo
 */
function showDemo() {
    showNotification('Demo video will be available soon! For now, try analyzing a sample portfolio.', 'info');
}

/**
 * Generate unique ID
 */
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * Format date for display
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/**
 * Debounce function for performance
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export functions for use in other modules
window.StockConsultant = {
    currentUser,
    userCredits,
    formatCurrency,
    formatLargeNumber,
    showNotification,
    deductCredits,
    recordUsage,
    generateId,
    formatDate,
    getRandomColor,
    debounce,
    API_BASE
};