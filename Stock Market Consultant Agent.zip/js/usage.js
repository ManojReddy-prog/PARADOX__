// Usage Tracking and Billing JavaScript
// Handles usage statistics, billing integration, and Flexprice functionality

/**
 * Load usage statistics
 */
async function loadUsageStats() {
    try {
        // Get overall statistics
        const response = await fetch(`${API_BASE}tables/usage_tracking?search=${currentUser}&limit=1000`);
        const result = await response.json();
        
        if (result.data) {
            const usageData = result.data;
            
            // Calculate statistics
            const stats = calculateUsageStats(usageData);
            
            // Update UI
            updateUsageStatsUI(stats);
            
            // Load usage history
            loadUsageHistory(usageData);
        }
    } catch (error) {
        console.error('❌ Error loading usage stats:', error);
    }
}

/**
 * Calculate usage statistics
 */
function calculateUsageStats(usageData) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const thisWeek = new Date(today.getTime() - (6 * 24 * 60 * 60 * 1000));
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const stats = {
        totalAnalyses: 0,
        totalCreditsUsed: 0,
        totalSpent: 0,
        todayUsage: 0,
        weeklyUsage: 0,
        monthlyUsage: 0,
        analysisCount: 0,
        reportCount: 0,
        adviceCount: 0,
        recentActivity: []
    };
    
    usageData.forEach(usage => {
        const usageDate = new Date(usage.timestamp);
        const cost = usage.cost || 0;
        
        // Total statistics
        stats.totalCreditsUsed += cost;
        stats.totalSpent += cost;
        
        if (usage.action_type === 'PORTFOLIO_ANALYSIS') {
            stats.analysisCount++;
            stats.totalAnalyses++;
        } else if (usage.action_type === 'REPORT_GENERATED') {
            stats.reportCount++;
        } else if (usage.action_type === 'STOCK_ADVICE') {
            stats.adviceCount++;
        }
        
        // Time-based statistics
        if (usageDate >= today) {
            stats.todayUsage += cost;
        }
        
        if (usageDate >= thisWeek) {
            stats.weeklyUsage += cost;
        }
        
        if (usageDate >= thisMonth) {
            stats.monthlyUsage += cost;
        }
        
        // Recent activity (last 10 items)
        if (stats.recentActivity.length < 10) {
            stats.recentActivity.push(usage);
        }
    });
    
    return stats;
}

/**
 * Update usage statistics UI
 */
function updateUsageStatsUI(stats) {
    // Update stat cards
    const totalAnalysesElement = document.getElementById('total-analyses');
    if (totalAnalysesElement) {
        totalAnalysesElement.textContent = stats.totalAnalyses;
    }
    
    const creditsUsedElement = document.getElementById('credits-used');
    if (creditsUsedElement) {
        creditsUsedElement.textContent = stats.totalCreditsUsed;
    }
    
    const totalSpentElement = document.getElementById('total-spent');
    if (totalSpentElement) {
        totalSpentElement.textContent = formatCurrency(stats.totalSpent);
    }
    
    const todayUsageElement = document.getElementById('today-usage');
    if (todayUsageElement) {
        todayUsageElement.textContent = stats.todayUsage;
    }
    
    // Animate counters
    animateCounters();
}

/**
 * Animate number counters
 */
function animateCounters() {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.textContent.replace(/[^0-9]/g, ''));
        if (target > 0) {
            let current = 0;
            const increment = target / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                
                if (counter.textContent.includes('₹')) {
                    counter.textContent = formatCurrency(Math.floor(current));
                } else {
                    counter.textContent = Math.floor(current);
                }
            }, 30);
        }
    });
}

/**
 * Load and display usage history
 */
function loadUsageHistory(usageData) {
    const historyList = document.getElementById('usage-history-list');
    if (!historyList) return;
    
    historyList.innerHTML = '';
    
    if (usageData.length === 0) {
        historyList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-history" style="font-size: 3rem; color: var(--gray-300); margin-bottom: 1rem;"></i>
                <p>No usage history yet. Start analyzing portfolios to see your activity here!</p>
            </div>
        `;
        return;
    }
    
    // Sort by most recent first
    const sortedUsage = usageData.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    sortedUsage.forEach((usage, index) => {
        const historyItem = document.createElement('div');
        historyItem.className = 'history-item';
        
        // Animation delay
        historyItem.style.animationDelay = `${index * 0.1}s`;
        historyItem.style.animation = 'fadeInUp 0.5s ease-out forwards';
        historyItem.style.opacity = '0';
        
        const actionIcon = getActionIcon(usage.action_type);
        const actionTitle = getActionTitle(usage.action_type);
        
        historyItem.innerHTML = `
            <div class="history-info">
                <div class="history-title">
                    <i class="${actionIcon}"></i>
                    ${actionTitle}
                </div>
                <div class="history-meta">
                    ${formatDate(usage.timestamp)} • ${usage.details || 'No additional details'}
                </div>
            </div>
            <div class="history-cost">₹${usage.cost}</div>
        `;
        
        historyList.appendChild(historyItem);
    });
}

/**
 * Get icon for action type
 */
function getActionIcon(actionType) {
    switch (actionType) {
        case 'PORTFOLIO_ANALYSIS':
            return 'fas fa-chart-pie';
        case 'REPORT_GENERATED':
            return 'fas fa-file-alt';
        case 'STOCK_ADVICE':
            return 'fas fa-lightbulb';
        default:
            return 'fas fa-coins';
    }
}

/**
 * Get title for action type
 */
function getActionTitle(actionType) {
    switch (actionType) {
        case 'PORTFOLIO_ANALYSIS':
            return 'Portfolio Analysis';
        case 'REPORT_GENERATED':
            return 'Detailed Report Generated';
        case 'STOCK_ADVICE':
            return 'Stock Advice Provided';
        default:
            return 'Credit Usage';
    }
}

/**
 * Filter usage history
 */
function filterUsageHistory() {
    const filter = document.getElementById('usage-filter').value;
    const now = new Date();
    let startDate;
    
    switch (filter) {
        case 'today':
            startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            break;
        case 'week':
            startDate = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
            break;
        case 'month':
            startDate = new Date(now.getFullYear(), now.getMonth(), 1);
            break;
        default:
            startDate = null;
    }
    
    // Re-load usage stats with filter
    loadUsageStatsWithFilter(startDate);
}

/**
 * Load usage stats with date filter
 */
async function loadUsageStatsWithFilter(startDate) {
    try {
        const response = await fetch(`${API_BASE}tables/usage_tracking?search=${currentUser}&limit=1000`);
        const result = await response.json();
        
        if (result.data) {
            let filteredData = result.data;
            
            if (startDate) {
                filteredData = result.data.filter(usage => {
                    const usageDate = new Date(usage.timestamp);
                    return usageDate >= startDate;
                });
            }
            
            loadUsageHistory(filteredData);
        }
    } catch (error) {
        console.error('❌ Error loading filtered usage stats:', error);
    }
}

/**
 * Flexprice Integration - Bill per usage
 */
class FlexpriceIntegration {
    constructor() {
        this.baseUrl = 'https://api.flexprice.com'; // Mock URL
        this.apiKey = 'demo_api_key'; // In real implementation, this would be secure
        this.rates = {
            'PORTFOLIO_ANALYSIS': 10,
            'REPORT_GENERATED': 5,
            'STOCK_ADVICE': 2
        };
    }
    
    /**
     * Calculate bill for action
     */
    calculateBill(actionType) {
        return this.rates[actionType] || 1;
    }
    
    /**
     * Process payment (mock implementation)
     */
    async processPayment(actionType, amount, metadata = {}) {
        try {
            // Simulate API call delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Mock successful payment response
            const paymentResult = {
                success: true,
                transactionId: `txn_${Date.now()}`,
                amount: amount,
                currency: 'INR',
                timestamp: new Date().toISOString(),
                actionType: actionType,
                metadata: metadata
            };
            
            console.log('💳 Payment processed:', paymentResult);
            
            // Record successful payment
            await this.recordPayment(paymentResult);
            
            return paymentResult;
        } catch (error) {
            console.error('❌ Payment processing failed:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    /**
     * Record payment in usage tracking
     */
    async recordPayment(paymentResult) {
        try {
            const usageData = {
                user_name: currentUser,
                action_type: paymentResult.actionType,
                cost: paymentResult.amount,
                timestamp: paymentResult.timestamp,
                details: `Transaction ID: ${paymentResult.transactionId}`
            };
            
            await fetch(`${API_BASE}tables/usage_tracking`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(usageData)
            });
            
            console.log('✅ Payment recorded in usage tracking');
        } catch (error) {
            console.error('❌ Error recording payment:', error);
        }
    }
    
    /**
     * Generate usage summary for billing
     */
    generateUsageSummary(usageData) {
        const summary = {
            user: currentUser,
            period: {
                start: new Date(Math.min(...usageData.map(u => new Date(u.timestamp)))).toISOString(),
                end: new Date().toISOString()
            },
            breakdown: {},
            total: 0
        };
        
        usageData.forEach(usage => {
            const actionType = usage.action_type;
            if (!summary.breakdown[actionType]) {
                summary.breakdown[actionType] = {
                    count: 0,
                    totalCost: 0,
                    rate: this.rates[actionType] || 1
                };
            }
            
            summary.breakdown[actionType].count += 1;
            summary.breakdown[actionType].totalCost += usage.cost;
            summary.total += usage.cost;
        });
        
        return summary;
    }
}

// Initialize Flexprice integration
const flexprice = new FlexpriceIntegration();

/**
 * Show usage billing modal
 */
function showUsageBilling() {
    // This would typically show a billing/subscription modal
    showNotification('Billing integration ready! Usage is tracked per analysis and report.', 'info');
}

/**
 * Purchase credits
 */
async function purchaseCredits(amount = 100) {
    try {
        const cost = amount; // 1 credit = ₹1 for demo
        
        showNotification('Processing payment...', 'info', 2000);
        
        const payment = await flexprice.processPayment('CREDIT_PURCHASE', cost, {
            credits: amount,
            user: currentUser
        });
        
        if (payment.success) {
            userCredits += amount;
            updateCreditsDisplay();
            showNotification(`Successfully purchased ${amount} credits!`, 'success');
        } else {
            showNotification('Payment failed. Please try again.', 'error');
        }
    } catch (error) {
        console.error('❌ Error purchasing credits:', error);
        showNotification('Error processing payment. Please try again.', 'error');
    }
}

/**
 * Export usage data
 */
async function exportUsageData() {
    try {
        const response = await fetch(`${API_BASE}tables/usage_tracking?search=${currentUser}&limit=1000`);
        const result = await response.json();
        
        if (result.data) {
            const csvData = convertToCSV(result.data);
            downloadCSV(csvData, `usage-report-${currentUser}-${new Date().toISOString().split('T')[0]}.csv`);
            showNotification('Usage data exported successfully!', 'success');
        }
    } catch (error) {
        console.error('❌ Error exporting usage data:', error);
        showNotification('Error exporting data. Please try again.', 'error');
    }
}

/**
 * Convert usage data to CSV
 */
function convertToCSV(data) {
    const headers = ['Date', 'Action Type', 'Cost (₹)', 'Details'];
    const csvRows = [headers.join(',')];
    
    data.forEach(usage => {
        const row = [
            new Date(usage.timestamp).toLocaleDateString('en-IN'),
            usage.action_type,
            usage.cost,
            `"${usage.details || ''}"` // Wrap in quotes for CSV
        ];
        csvRows.push(row.join(','));
    });
    
    return csvRows.join('\n');
}

/**
 * Download CSV file
 */
function downloadCSV(csvData, filename) {
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
}

/**
 * Real-time usage tracking
 */
function trackUserInteraction(actionType, metadata = {}) {
    // Track user interactions for analytics
    console.log(`📊 User interaction: ${actionType}`, metadata);
    
    // This could send data to analytics service
    // analytics.track(actionType, metadata);
}

/**
 * Usage analytics dashboard
 */
function showUsageAnalytics() {
    // This would show detailed analytics charts
    showNotification('Advanced analytics dashboard coming soon!', 'info');
}

// Export for global use
window.UsageTracking = {
    loadUsageStats,
    filterUsageHistory,
    purchaseCredits,
    exportUsageData,
    trackUserInteraction,
    flexprice
};

// Track page interactions
document.addEventListener('DOMContentLoaded', function() {
    // Track page load
    trackUserInteraction('PAGE_LOAD', {
        page: 'stock_consultant',
        timestamp: new Date().toISOString()
    });
    
    // Track scroll events (debounced)
    let scrollTimeout;
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => {
            const scrollPercentage = Math.round(
                (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100
            );
            if (scrollPercentage % 25 === 0) { // Track every 25%
                trackUserInteraction('SCROLL', { percentage: scrollPercentage });
            }
        }, 250);
    });
    
    // Track section visibility
    const sections = document.querySelectorAll('section[id]');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                trackUserInteraction('SECTION_VIEW', {
                    section: entry.target.id,
                    timestamp: new Date().toISOString()
                });
            }
        });
    }, { threshold: 0.5 });
    
    sections.forEach(section => observer.observe(section));
});