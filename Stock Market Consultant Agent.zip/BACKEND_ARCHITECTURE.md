# Backend Architecture & Code Documentation

## 🏗️ Backend Components Overview

The Stock Consultant Agent uses a **client-side architecture** with **RESTful Table API** for data persistence. Here's how the backend components are organized:

## 📂 Backend Code Organization

### Frontend Files (Client-Side)
```
📁 Frontend/
├── 🌐 index.html              # Main application interface
├── 🎨 css/main.css            # Complete styling system  
└── 💻 js/                     # JavaScript modules
    ├── main.js                # Core utilities & initialization
    ├── portfolio.js           # Portfolio management & analysis
    ├── analysis.js            # Results visualization & charts
    └── usage.js               # Billing & usage tracking
```

### Backend Services (API Layer)

#### 1. **RESTful Table API** (Data Persistence Layer)
```javascript
// Base API configuration
const API_BASE = '';  // Relative URL for table operations

// CRUD Operations Examples:
GET    /tables/{table_name}                    # List records
POST   /tables/{table_name}                    # Create record  
GET    /tables/{table_name}/{record_id}        # Get record
PUT    /tables/{table_name}/{record_id}        # Update record
DELETE /tables/{table_name}/{record_id}        # Delete record
```

#### 2. **Database Schema Management**
```javascript
// Table definitions (js/main.js)
TableSchemaUpdate('portfolios', {
    id: 'text',
    user_name: 'text', 
    portfolio_name: 'text',
    stocks: 'array',
    total_investment: 'number',
    created_date: 'datetime',
    last_analyzed: 'datetime'
});
```

#### 3. **Stock Data Service** (Mock Pathway Integration)
```javascript
// Mock stock data simulation (js/main.js)
async function initializeMockStockData() {
    // Creates 10+ Indian stocks with live-like data
    // Simulates NSE/BSE market data
    // Updates prices with realistic fluctuations
}

// Stock data structure:
{
    symbol: 'TCS',
    company_name: 'Tata Consultancy Services', 
    current_price: 3420.75,
    day_change: 2.5,
    market_cap: 1250000000000,
    pe_ratio: 28.5,
    sector: 'Information Technology',
    last_updated: '2024-12-19T10:00:00.000Z'
}
```

## 🔧 Backend Processing Logic

### 1. **Portfolio Analysis Engine** (`js/portfolio.js`)

#### Core Analysis Pipeline:
```javascript
async function analyzePortfolio() {
    // Step 1: Validate input data
    if (!validatePortfolioForm()) return;
    
    // Step 2: Check user credits  
    if (!await deductCredits(10, 'PORTFOLIO_ANALYSIS')) return;
    
    // Step 3: Execute 4-phase analysis
    await performAnalysisSteps(portfolioData);
    
    // Step 4: Save results to database
    await savePortfolioAndAnalysis(portfolioData);
    
    // Step 5: Display results
    showAnalysisResults();
}
```

#### AI Analysis Algorithm:
```javascript
async function performAIAnalysis(portfolioData) {
    const recommendations = [];
    
    // Individual stock analysis
    stocks.forEach(stock => {
        const pnlPercentage = stock.pnl_percentage || 0;
        const peRatio = stock.pe_ratio || 20;
        
        // AI Logic Rules:
        if (pnlPercentage < -15) {
            recommendation = 'SELL';
            reason = 'Significant decline detected';
            riskLevel = 'HIGH';
        } else if (pnlPercentage > 25) {
            recommendation = 'HOLD';  
            reason = 'Strong performance, consider profit booking';
            riskLevel = 'MEDIUM';
        } else if (peRatio > 40) {
            recommendation = 'SELL';
            reason = 'Overvalued based on PE ratio';
            riskLevel = 'HIGH';
        } else if (peRatio < 12 && ['Banking', 'FMCG'].includes(sector)) {
            recommendation = 'BUY';
            reason = 'Undervalued opportunity';  
            riskLevel = 'LOW';
        } else {
            recommendation = 'HOLD';
            reason = 'Fairly valued, maintain position';
            riskLevel = 'MEDIUM';
        }
    });
    
    // Portfolio-level recommendations  
    const sectorCount = Object.keys(metrics.sectorAllocation).length;
    if (sectorCount < 3) {
        recommendations.push({
            recommendation: 'DIVERSIFY',
            reason: 'Portfolio lacks diversification'
        });
    }
}
```

### 2. **Live Data Processing** (`js/portfolio.js`)

```javascript
async function fetchLiveStockData(stocks) {
    for (const stock of stocks) {
        // Fetch current market data
        const response = await fetch(`${API_BASE}tables/stock_data?search=${stock.symbol}`);
        const stockData = await response.json();
        
        if (stockData.data?.[0]) {
            // Calculate real-time metrics
            stock.current_price = stockData.data[0].current_price;
            stock.current_value = stock.quantity * stock.current_price;
            stock.pnl = stock.current_value - (stock.quantity * stock.avg_price);
            stock.pnl_percentage = (stock.pnl / (stock.quantity * stock.avg_price)) * 100;
        }
    }
}
```

### 3. **Billing & Usage Tracking Backend** (`js/usage.js`)

#### Flexprice Integration:
```javascript
class FlexpriceIntegration {
    constructor() {
        this.rates = {
            'PORTFOLIO_ANALYSIS': 10,  // ₹10 per analysis
            'REPORT_GENERATED': 5,     // ₹5 per report
            'STOCK_ADVICE': 2          // ₹2 per advice
        };
    }
    
    async processPayment(actionType, amount, metadata) {
        // Simulate payment processing
        const paymentResult = {
            success: true,
            transactionId: `txn_${Date.now()}`,
            amount: amount,
            timestamp: new Date().toISOString()
        };
        
        // Record in usage tracking
        await this.recordPayment(paymentResult);
        return paymentResult;
    }
}
```

#### Usage Analytics:
```javascript
async function loadUsageStats() {
    // Fetch user usage data
    const response = await fetch(`${API_BASE}tables/usage_tracking?search=${currentUser}`);
    const usageData = await response.json();
    
    // Calculate statistics
    const stats = {
        totalAnalyses: 0,
        totalCreditsUsed: 0, 
        todayUsage: 0,
        monthlyUsage: 0
    };
    
    // Process and display metrics
    usageData.data.forEach(usage => {
        stats.totalCreditsUsed += usage.cost;
        if (isToday(usage.timestamp)) {
            stats.todayUsage += usage.cost;
        }
    });
}
```

## 📊 Data Flow Architecture

### 1. **User Input → Analysis Pipeline**
```
User Portfolio Input
      ↓
Form Validation
      ↓  
Credit Check & Deduction
      ↓
Live Stock Data Fetch  
      ↓
Portfolio Metrics Calculation
      ↓
AI Analysis & Recommendations
      ↓
Results Visualization
      ↓
Database Storage
```

### 2. **Real-time Progress Tracking**
```javascript
// Progress tracking system
async function performAnalysisSteps(portfolioData) {
    // Step 1: Fetch live data (25%)
    updateProgressStep(1, 'active');
    await fetchLiveStockData(portfolioData.stocks);
    updateProgressStep(1, 'completed');
    
    // Step 2: Calculate metrics (50%)  
    updateProgressStep(2, 'active');
    await calculatePortfolioMetrics(portfolioData);
    updateProgressStep(2, 'completed');
    
    // Step 3: AI analysis (75%)
    updateProgressStep(3, 'active'); 
    await performAIAnalysis(portfolioData);
    updateProgressStep(3, 'completed');
    
    // Step 4: Generate report (100%)
    updateProgressStep(4, 'active');
    await generateAnalysisReport(portfolioData);
    updateProgressStep(4, 'completed');
}
```

### 3. **Database Operations**

#### Portfolio Storage:
```javascript
async function savePortfolio() {
    const portfolioData = {
        id: generateId(),
        user_name: investorName,
        portfolio_name: portfolioName,
        stocks: stocksArray,
        total_investment: totalInvestment,
        created_date: new Date().toISOString()
    };
    
    const response = await fetch(`${API_BASE}tables/portfolios`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(portfolioData)
    });
}
```

#### Analysis Results Storage:
```javascript  
async function saveAnalysisResults(recommendations) {
    for (const rec of recommendations) {
        const analysisData = {
            portfolio_id: portfolioData.id,
            stock_symbol: rec.stock_symbol,
            recommendation: rec.recommendation, 
            reason: rec.reason,
            risk_level: rec.risk_level,
            analysis_date: new Date().toISOString()
        };
        
        await fetch(`${API_BASE}tables/stock_analyses`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(analysisData)
        });
    }
}
```

## 🔄 API Integration Points

### 1. **Mock Pathway Data Service**
```javascript
// Simulates live stock market data
const mockStocks = [
    {
        symbol: 'TCS',
        current_price: 3420.75,
        day_change: 2.5,
        sector: 'Information Technology'
    },
    // ... more stocks
];

// Updates prices with realistic market movements  
function simulatePriceMovement(stock) {
    const volatility = 0.02; // 2% daily volatility
    const change = (Math.random() - 0.5) * volatility;
    stock.current_price *= (1 + change);
    stock.day_change = (change * 100);
}
```

### 2. **Billing Integration**
```javascript
// Credit management system
async function deductCredits(amount, actionType, details) {
    if (userCredits >= amount) {
        userCredits -= amount;
        updateCreditsDisplay();
        
        // Record usage for billing
        await recordUsage(actionType, amount, details);
        return true;
    } else {
        showNotification('Insufficient credits');
        return false;
    }
}
```

## 🚀 Performance Optimizations

### 1. **Caching Strategy**
```javascript
// Cache stock data to reduce API calls
const stockDataCache = new Map();

async function getCachedStockData(symbol) {
    const cacheKey = `${symbol}_${new Date().getDate()}`;
    
    if (stockDataCache.has(cacheKey)) {
        return stockDataCache.get(cacheKey);
    }
    
    const freshData = await fetchStockData(symbol);
    stockDataCache.set(cacheKey, freshData);
    return freshData;
}
```

### 2. **Async Processing**
```javascript
// Parallel data fetching for better performance
async function fetchMultipleStocks(symbols) {
    const promises = symbols.map(symbol => 
        fetch(`${API_BASE}tables/stock_data?search=${symbol}`)
    );
    
    const results = await Promise.all(promises);
    return Promise.all(results.map(r => r.json()));
}
```

## 🔐 Security Implementation

### 1. **Input Validation**
```javascript
function validateStockSymbol(symbol) {
    // Prevent SQL injection and XSS
    return /^[A-Z0-9]{2,10}$/i.test(symbol);
}

function sanitizeUserInput(input) {
    return input.trim().replace(/[<>\"\']/g, '');
}
```

### 2. **Rate Limiting**
```javascript
const rateLimiter = {
    requests: new Map(),
    
    checkLimit(userId) {
        const now = Date.now();
        const userRequests = this.requests.get(userId) || [];
        
        // Remove requests older than 1 hour
        const recentRequests = userRequests.filter(
            time => now - time < 3600000
        );
        
        if (recentRequests.length >= 10) {
            return false; // Rate limited
        }
        
        recentRequests.push(now);
        this.requests.set(userId, recentRequests);
        return true;
    }
};
```

## 📈 Scalability Considerations

### 1. **Database Optimization**
- Indexed queries for fast portfolio lookups
- Paginated results for large datasets  
- Efficient data structures for analytics

### 2. **Modular Architecture**
- Separated concerns (analysis, visualization, billing)
- Reusable components and utilities
- Easy integration of new features

### 3. **Error Handling**
```javascript
async function robustApiCall(url, options) {
    const maxRetries = 3;
    
    for (let i = 0; i < maxRetries; i++) {
        try {
            const response = await fetch(url, options);
            if (response.ok) return response;
        } catch (error) {
            if (i === maxRetries - 1) throw error;
            await new Promise(resolve => setTimeout(resolve, 1000 * i));
        }
    }
}
```

This backend architecture provides a solid foundation for the Stock Consultant Agent while maintaining simplicity and performance.